Pop! Jelly PangPang — Fan Kit (stickers & loops)

[English]
Feel free to use these in memes, fan art, stream overlays and thumbnails.
Please don't use them on merchandise for sale.
A credit is always appreciated: "Pop! Jelly PangPang"

[한국어]
밈, 팬아트, 방송 화면, 썸네일에 마음대로 써도 됩니다.
판매용 굿즈에는 쓰지 말아 주세요.
출처를 적어 주시면 고마워요: "Pop! Jelly PangPang"

[日本語]
ミーム、ファンアート、配信画面、サムネイルに自由に使ってOKです。
販売用グッズへの使用はご遠慮ください。
クレジットを書いてもらえるとうれしいです:「Pop! Jelly PangPang」

----
stickers/512, stickers/1024 : transparent PNG (20 poses)
loops/*.gif, loops/*.webm   : transparent loops under 2 seconds (bounce, pop, dance, stretch, spin)
