Pop! JellyPangPang — Sticker Kit (2026-11-20)

[English]
Free. Use freely in monetized streams, thumbnails and fan art.
Do not sell or redistribute the assets themselves.
A credit is always appreciated: "Pop! JellyPangPang"

[한국어]
무료 · 수익화 방송, 썸네일, 팬아트 자유 · 소재 자체 판매와 재배포 금지
출처를 적어 주시면 고마워요: "Pop! JellyPangPang"

[日本語]
無料・収益化した配信、サムネイル、ファンアートに自由に使えます・素材そのものの販売と再配布は禁止です
クレジットを書いてもらえるとうれしいです:「Pop! JellyPangPang」

More languages: https://jellypangpang1231.github.io/fankit/

----
emotes/twitch/     28, 56, 112 PNG (9 emotes)
emotes/discord/    128 PNG
emotes/youtube/    480 PNG
badges/            Sub badges 18, 36, 72 PNG (3 tiers)
discord_stickers/  25 stickers, 320x320 PNG
stickers/          25 transparent stickers, 512 and 1024 PNG
loops/             5 transparent loops under 2 s, GIF + WebM (bounce, pop, dance, stretch, spin)

Scene frames, webcam frames, alerts and the green-screen loops are in the Stream Kit on the same page.
