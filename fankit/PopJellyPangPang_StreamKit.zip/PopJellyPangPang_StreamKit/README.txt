Pop! JellyPangPang — Stream Kit (2026-11-20)

[English]
Free. Use freely in monetized streams, thumbnails and fan art.
Do not sell or redistribute the assets themselves.
A credit is always appreciated: "Pop! JellyPangPang"

[한국어]
무료 · 수익화 방송, 썸네일, 팬아트 자유 · 소재 자체 판매와 재배포 금지
출처를 적어 주시면 고마워요: "Pop! JellyPangPang"

[日本語]
無料・収益化した配信、サムネイル、ファンアートに自由に使えます・素材そのものの販売と再配布は禁止です
クレジットを書いてもらえるとうれしいです:「Pop! JellyPangPang」

More languages: https://jellypangpang1231.github.io/fankit/

----
scenes/            Starting soon / Be right back / Thanks for watching
                   1920x1080 and vertical 1080x1920 PNG · ko, en, ja, zh-Hant, none (no text)
webcam/            Webcam frames, transparent PNG · 16x9 (960x540 hole), 4x3, 1x1, round · pink, mint
roomcode/          "Join my room" card with an empty code box (put an OBS text source on it) · ko, en, ja, zh-Hant
alerts/            Follower alert, transparent WebM + GIF (4 s) · blank band for alert-box text · alert_pop.mp3/.ogg/.wav
greenscreen/       Jelly loops on #00FF00, 1920x1080 and 1080x1920 MP4 (key out the green in your editor)

Stickers, emotes and badges are in the Sticker Kit on the same page.
